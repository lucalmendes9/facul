<?php /* C:\Users\COMPUTER\Desktop\desafioCalcNum\calculo-num\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php */ ?>
<?php echo e($slot); ?>

