<?php /* C:\Users\COMPUTER\Desktop\desafioCalcNum\calculo-num\resources\views/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container raphson">
    <div class="row justify-content-center">
        <div class="bloco">
            <div class="col-sm-3 campos">
                <label for="funcao">Função f(x):</label>
                <input type="text" id="funcao" value="e^x-5*x" placeholder="Digite a função..." >
            </div>
            <div class="col-sm-3 campos">
                <label for="intervalo">Intervalo:</label>
                <input type="text" id="intervalo_de" value="0" placeholder="De..." >
                <input type="text" id="intervalo_ate" value="1" placeholder="Até..." >
            </div>
            <div class="col-sm-3 campos">
                <label for="erro">Erro:</label>
                <input type="text" id="erro" value="0.005" placeholder="Erro menor que..." >
            </div>
            <div class="col-sm-2 btns">
                <a href="#" id="calcular">Calcular</a>
                <a href="#" id="reset">Reset</a>
            </div>
            <div class="col-sm-3 campos resultDerivate">
                <label for="funcao">f'(x) (Derivada):<br><span>-</span></label>
            </div>
        </div>
    </div>
    <div class="row tentativas">
            <div class="col-sm-2"><h4>Xk</h4></div>
            <div class="col-sm-2"><h4>F(Xk)</h4></div>
            <div class="col-sm-2"><h4>F'(Xk)</h4></div>
            <div class="col-sm-2"><h4>Xk+1</h4></div>
            <div class="col-sm-2"><h4>F(Xk+1)</h4></div>
            <div class="col-sm-2"><h4>|F(Xk+1)| < E</h4></div>
    </div>
    <div id="myPlot" style="width:100%;height:400px;"></div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>